# Listing of the expected final test cases

**1.** Character moves successfully.

**2.** Character moves into an obstacle and the game ends with defeat.

**3.** Character doesn't exceed the Bottom limit .

**4.** Character doesn't exceed the Upper limit .

**5.** Obstacles appear randomly.

**6.** Character gets a power-up successfully.
