# Final Project Intermediate Check-Point

**Architecture Design**
* [UML](https://github.com/davidrsfalcao/LPOO1617_T5G2/blob/final-project/Intermediate%20Check-Point/JetPoo.pdf) 
* [Behavioural Aspect](https://github.com/davidrsfalcao/LPOO1617_T5G2/blob/final-project/Intermediate%20Check-Point/Behavioural%20Automaton.pdf)

**GUI Design**
* [Main functionalities](https://github.com/davidrsfalcao/LPOO1617_T5G2/blob/final-project/Intermediate%20Check-Point/GUI%20functionalities.md)
* [GUI mock-ups](https://github.com/davidrsfalcao/LPOO1617_T5G2/blob/final-project/Intermediate%20Check-Point/GUI%20mock-ups.pdf)

**Test Design**

* [Test cases](https://github.com/davidrsfalcao/LPOO1617_T5G2/blob/final-project/Intermediate%20Check-Point/Test%20Cases.md)

